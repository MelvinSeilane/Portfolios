﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.ConstrainedExecution;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;

namespace City_Library
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //Declarations
            string firstName; string lastName; int booksBorrowed; double ratePerBook;
            int numDays = 0;
            List<Borrower> borrowers = new List<Borrower>();

            Console.WriteLine("Memory before allocation: {0} bytes", GC.GetTotalMemory(false));

            //Input
            Console.Write("Enter First Name: "); firstName = Console.ReadLine();
            Console.Write("Enter Last Name: "); lastName = Console.ReadLine();
            Console.Write("Enter how many books were borrowed: "); booksBorrowed = Convert.ToInt32(Console.ReadLine());
            Console.Write("Enter the price per book: R"); ratePerBook = Convert.ToDouble(Console.ReadLine());

            Console.WriteLine();
            Console.Write("Enter how long the books were borrowed: "); numDays = Convert.ToInt32(Console.ReadLine());

            //Process
            for (int i = 0; i < 120; i++) 
            {
                borrowers.Add(new Borrower());
            }

            
            GC.GetTotalMemory(false);
            borrowers[5 - 1] = new Borrower(firstName, lastName, booksBorrowed, ratePerBook);
            borrowers[5 - 1].Fine = 100;

            Console.WriteLine("The generation of borrower 5 is {0}", GC.GetGeneration(borrowers[5 - 1]));
            Console.WriteLine("The generation of borrower 3 is {0}", GC.GetGeneration(borrowers[3 - 1]));
            Console.WriteLine();

            GC.Collect();
            //Output
            Console.WriteLine("There are {0} users who decided to borrow books. ", borrowers.Count);
            Console.WriteLine();

            Console.WriteLine("User {0} records: ", 5);
            Console.WriteLine("-----------------------");
            Console.WriteLine("Name: {0} {1}", borrowers[5 - 1].getFirstName, borrowers[5 - 1].getLastName);
            Console.WriteLine("Books Borrowed: {0}", borrowers[5 - 1].getBooksBorrowed);
            Console.WriteLine("Price: R{0} x {1}", borrowers[5-1].getRatePerBook, borrowers[5 - 1].getBooksBorrowed);
            Console.WriteLine("Duration: {0} days", numDays);
            Console.WriteLine();
            Console.WriteLine("Total: R{0}", borrowers[5-1].Total(numDays));
            Console.WriteLine();
            Console.WriteLine();
            Console.WriteLine("Total bytes in the heap : {0}", GC.GetTotalMemory(false));
            Console.WriteLine("The generation of borrower 5 is {0}", GC.GetGeneration(borrowers[5 - 1]));
            Console.WriteLine("The generation of borrower 3 is {0}", GC.GetGeneration(borrowers[3 - 1]));

            //Execute
            Console.ReadKey();
        }
    }
}