﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace City_Library
{
    public class Borrower
    {
        //Fields
        private string firstName;
        private string lastName;
        private int booksBorrowed;
        private double ratePerBook;
        private double fine;
        private double total;

        //Constructor
        public Borrower()
        {
        }

        public Borrower(string firstName, string lastName, int booksBorrowed, double ratePerBook)
        {
            this.firstName = firstName;
            this.lastName = lastName;
            this.booksBorrowed = booksBorrowed;
            this.ratePerBook = ratePerBook;
        }

        public double Fine { set {  fine = value; } }
        public string getFirstName { get { return firstName; } }
        public string getLastName { get { return lastName; } }
        public int getBooksBorrowed { get {  return booksBorrowed; } }
        public double getRatePerBook { get {  return ratePerBook; } }
        //public double Total { get { return total; } }
        
        /*
         fine + 
            {15% of the total 6-10 days
             25% of the total >10 days}
         */
        public double Total(int numDays) 
        {
            total = booksBorrowed * ratePerBook;

            if (numDays < 6)
            { }
            else
            {
                if (numDays >= 6 || numDays < 10) 
                {
                    total = fine + total + (0.15 * total); 
                }
                else
                {
                    if(numDays >= 10) 
                    {
                        total = fine + total + (0.25 * total);
                    }
                }
            }
            return total;
        }
    }
}