﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ice_Task3
{
    internal class Program
    {
        static void Main(string[] args)
        {
            List<int> nums = new List<int>();
            nums.Add(9);
            nums.Add(6);
            nums.Add(0);
            nums.Add(3);
            nums.Add(5);

            //Question 1
            List<int> copy = new List<int>();
            for (int i = 0; i < nums.Count; i++) 
            {
                copy.Add(nums[i]);
            }

            Console.Write("This is the list of the arrays in 'nums': ");
            for (int i = 0;i < nums.Count; i++) 
            {
                Console.Write(nums[i] + " ");
            }
            Console.WriteLine();

            Console.Write("This is a copy: ");
            for (int i = 0; i < nums.Count; i++)
            {
                Console.Write(nums[i] + " ");
            }
            Console.WriteLine();
            Console.WriteLine();

            //Question 2
            List<int> nums2 = new List<int>();
            for(int i = 0;i < nums.Count ; i++) 
            {
                nums2.Add(nums[i] + 7);
            }

            int temp = 0;
            for (int i = 0; i < (nums.Count); i++) 
            {
                for (int j = 0; j < (nums.Count - 1); ++j)
                {
                    if ((nums[j] > nums[j + 1]))
                    {
                        temp = nums[j];
                        nums[j] = nums[j + 1];
                        nums[j + 1] = temp;
                    }
                    if ((nums2[j] > nums2[j + 1]))
                    {
                        temp = nums2[j];
                        nums2[j] = nums2[j + 1];
                        nums2[j + 1] = temp;
                    }
                }
            }

            Console.Write("This is the array(num) arranged in acending order: ");
            for (int i = 0; i < nums.Count; i++)
            {
                Console.Write(nums[i] + ",");
            }
            Console.WriteLine();

            Console.Write("This is the array(num2) arranged in acending order: ");
            for (int i = 0; i < nums2.Count; i++)
            {
                Console.Write(nums2[i] + ",");
            }
            Console.WriteLine();
            Console.WriteLine();

            //Question 3
            List<int> inputs = new List<int>();
            bool decide = true;
            string stop = "";

            while (decide)
            {
                Console.Write("Enter stop or a number: "); 
                stop = Console.ReadLine();
                if (stop.Equals("stop", StringComparison.OrdinalIgnoreCase))
                {
                    break;
                }
                else
                {
                    inputs.Add(Convert.ToInt32(stop));
                }
            }
            Console.WriteLine();
            Console.Write("Here is your list:");
            for (int i = 0; i < inputs.Count; i++)
            {
                Console.Write(inputs[i] + " ");
            }
            Console.WriteLine();
            Console.WriteLine();

            //Question 4
            List<int> even = new List<int>();
            List<int> odd = new List<int> ();
            int watNum = 0;

            Console.Write("Enter 10 number: ");
            for(int i = 0;i < 10;i++) 
            {
                watNum = Convert.ToInt32(Console.ReadLine());

                if ((watNum%2) == 0) 
                {
                    even.Add(watNum);
                }
                else 
                {
                    odd.Add(watNum);
                }

            }

            Console.Write("Here is your even list:");
            for (int i = 0; i < even.Count; i++)
            {
                Console.Write(even[i] + " ");
            }
            Console.WriteLine();

            Console.Write("Here is your odd list:");
            for (int i = 0; i < odd.Count; i++)
            {
                Console.Write(odd[i] + " ");
            }
            Console.WriteLine();

            Console.ReadKey();
        }

        
    }
}
