/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package bubblesort;

import java.util.Scanner;

/**
 *
 * @author kamogelo seilane
 */
public class BubbleSort {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        final int SIZE = 5;
        int[] score = new int[SIZE];
        final int COMP = SIZE - 1;
        
        
        fillArray(SIZE, score);
        sortArray(score, COMP);
        System.out.println("Final list: " + score[0]+ " " + score[1] + " " + score[2] + " " + score[3] + " " + score[4]);
    }
    public static void fillArray(int SIZE, int[] array)
    {
        Scanner input = new Scanner(System.in);
        System.out.print("Enter the first 5 elements: ");
        int inputNumber;
        for(int x = 0; x < SIZE; ++x)
        {
            
            inputNumber = input.nextInt();
            array[x] = inputNumber;
            System.out.print( array[x] + " ");
        }
        System.out.println("Initial list: " + array[0]+ " " + array[1] + " " + array[2] + " " + array[3] + " " + array[4]);
    }
    
    public static void sortArray(int[] array,int COMP)
    {
        int tempscore;
     for(int x = 0; x < COMP; ++x)
     {
         for(int y = 0; y < COMP; ++y)
         {
             if(array[y] > array[y + 1])
             {
                 tempscore = array[y + 1];
                 array[y + 1] = array[y];
                 array[y] = tempscore;
             }
         }
     }
    }
}
