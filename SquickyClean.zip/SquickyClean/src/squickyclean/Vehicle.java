/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package squickyclean;

import javax.swing.JOptionPane;

/**
 *
 * @author Acer
 */
public class Vehicle {
    private String[] cars = {"minibus","SUV","Sedan","Hatchback"};
    private String car;
    private final double[] carPrices = {350,250,150,75};
    private double Price;
    //private int decision;
    private final double valetPrice = 50;
    //private int xtraDecisions;

    public Vehicle(int decision, int xtraDecisions) {
        decision = JOptionPane.showOptionDialog(null, "What type of car do you have?", "Squicky Clean", 0, JOptionPane.PLAIN_MESSAGE, null, cars, null);
        car = cars[decision];
        Price = carPrices[decision];
        
        xtraDecisions = JOptionPane.showConfirmDialog(null, "Would you like to include valet washing", "Squicky Clean", JOptionPane.YES_NO_OPTION);
        System.out.println("xtraDecisions is " + xtraDecisions);
        
        if(xtraDecisions == JOptionPane.YES_OPTION)
        {
            Price = Price + valetPrice;
        }
        
    }

    public void setPrice(double Price) {
        this.Price = Price;
    }

    
    
    
}
