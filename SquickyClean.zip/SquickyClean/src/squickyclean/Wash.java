/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package squickyclean;

/**
 *
 * @author Acer
 */
public class Wash extends Vehicle { 
    
    
    private int duration;
    private String[] wash = {"Wash only","Interior Cleaning","Full Wash"};
    private int[] washPrice = {100,50,200};
    private final int polishCost = 25;

    public Wash(int decision, int xtraDecisions) {
        super(decision, xtraDecisions);
    }

    
    
    
}
