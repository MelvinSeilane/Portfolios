﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bank_program
{
    internal class Program
    {
        static void Main(string[] args)
        {
            string input;
            int accOption;
            int option;
            int tranSOption;
            double cash = 0;
            double amount = 0;
            double total = 0;
            double dep;
            bool exit = true;
            Account[] accounts = new Account[2];
            accounts[0] = new Account();
            accounts[1] = new Account();

            //The user must select what account they would like to use
            Console.WriteLine("Welcome User, select account:");
            Console.WriteLine("1)Savings");
            Console.WriteLine("2)Cheque");
            Console.Write("Enter option:");
            input = Console.ReadLine();

            //This is to check if a user inputs a digit
            while (true)
            {
                if (int.TryParse(input, out accOption))
                {
                    accOption = Convert.ToInt32(input);
                    break;
                }
                else
                {
                    Console.WriteLine("Invalid Input, Enter a Digit!!!");
                }
            }
            while (exit)
            {
                //The user must select what their account must do
                Console.WriteLine("Welcome User, which transaction would you like to perform today:");
                Console.WriteLine("1)Transaction");
                Console.WriteLine("2)Check Balance");
                Console.WriteLine("3)Exit");
                Console.Write("Enter option:");
                input = Console.ReadLine();

                //This is to check if a user inputs a digit
                while (true)
                {
                    if (int.TryParse(input, out option))
                    {
                        option = Convert.ToInt32(input);
                        break;
                    }
                    else
                    {
                        Console.WriteLine("Invalid Input, Enter a Digit!!!");
                    }
                }
                Console.WriteLine();

                switch (option)
                {
                    case 1:
                        //User selects what type of transaction they would like to do
                        Console.WriteLine("What would you like to do?");
                        Console.WriteLine("1)Withdraw");
                        Console.WriteLine("2)Deposit");
                        Console.Write("Enter option:");
                        input = Console.ReadLine();

                        //This is to check if a user inputs a digit
                        while (true)
                        {
                            if (int.TryParse(input, out tranSOption))
                            {
                                tranSOption = Convert.ToInt32(input);
                                break;
                            }
                            else
                            {
                                Console.WriteLine("Invalid Input, Enter a Digit!!!");
                            }
                        }

                        //This switch statements will allow the user to select the type of transaction they would like to perform
                        switch (tranSOption)
                        {
                            case 1:
                                total = accounts[accOption -1].Withdrawal(amount);

                                Console.WriteLine($"Your balance is: R{total}");
                                break;
                            case 2:
                                dep = accounts[accOption -1].Cash(cash);

                                Console.WriteLine($"You have successfully deposited R{dep}");
                                break;
                            default:
                                Console.WriteLine("Invalid option");
                                break;
                        }
                        Console.WriteLine();
                        break;
                    case 2:

                        Console.WriteLine(accounts[accOption -1].balnce());
                        Console.WriteLine();
                        break;
                    case 3:
                        exit = false;
                        break;
                    default:
                        Console.WriteLine("Invalid option");
                        break;
                }
            }
        }
    }


        class Account
        {
            private double balance = 0;
            private double deposit;
            private double withdraw;

        //this method will be for depositing cash
            public double Cash(double cash)
            {
                Console.Write("How much are you depositing: ");
                cash = Convert.ToDouble(Console.ReadLine());

                balance = balance + cash;

                return balance;
            }

        //This method will be for withdrawing money
            public double Withdrawal(double amount) 
            {
                Console.WriteLine("how much you want to withdraw: ");
                amount = Convert.ToDouble(Console.ReadLine());

                if(balance > 0 && balance >= amount)
                {
                    Console.WriteLine("withdrawal successful");
                    balance = balance - amount;
                }
                else
                {
                    Console.WriteLine("invalid funds!!!!");
                }


                return balance;
            }

        //This method returns your balance
            public string balnce()
            {
                return $"Your balance is: R{balance}";
            }
        }
    }

