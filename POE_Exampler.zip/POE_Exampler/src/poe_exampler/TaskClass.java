/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package poe_exampler;

import javax.swing.JOptionPane;

/**
 *
 * @author kamogelo seilane
 */
public class TaskClass {
    
    public static void AddTask(int totalHours, int option)
    {
        
        String storingTasks;
        int numOfTasks;
        String numOfTasksStr;
        String TaskName;
        int TaskNum;
        String TaskDescription;
        String devDetails;
        String hrsInStr;
        double TaskDuration;
        String TaskID;
        String[] tskStatus = {"To Do", "Done", "Doing"};
        String TaskStatus;
        
        StoreTasks store = new StoreTasks();
        String[] optionsTwo = {"Task's Done", "Longest Task", "Searching Task Name", "Searching Developer", "Delete Task", "Display all tasks"};
        int optionTwo;
        
        numOfTasksStr = JOptionPane.showInputDialog(null, "How many Tasks would you like to add:", "Add Tasks", JOptionPane.QUESTION_MESSAGE);
        numOfTasks = Integer.parseInt(numOfTasksStr);
        for(int c = 0; c < numOfTasks; ++c)//For loop is for number of tasks to be filled in
        {
            TaskName = JOptionPane.showInputDialog(null,  "What is the name of your task: ", "Add Tasks", JOptionPane.QUESTION_MESSAGE);
            TaskNum = c;
            TaskDescription = JOptionPane.showInputDialog(null,  "What is the task description for Task " + TaskNum + ": ", "Add Tasks", JOptionPane.QUESTION_MESSAGE);
            while(TaskClass.checkTaskDescription(TaskDescription) != true)
            {
                JOptionPane.showMessageDialog(null, "Please enter a task description of less than 50 characters", "Add Tasks", JOptionPane.ERROR_MESSAGE);
                TaskDescription = JOptionPane.showInputDialog(null,  "What is the task description for Task " + TaskNum + ": ", "Add Tasks", JOptionPane.QUESTION_MESSAGE);
            }
            JOptionPane.showMessageDialog(null, "Task successfully captured", "Add Tasks", JOptionPane.INFORMATION_MESSAGE);
            
            devDetails = JOptionPane.showInputDialog(null,  "The first and last name of the developer assigned to the task: ", "Add Tasks", JOptionPane.QUESTION_MESSAGE);
            
            hrsInStr = JOptionPane.showInputDialog(null,  "How long will the task take you to complete in hours: ", "Add Tasks", JOptionPane.QUESTION_MESSAGE);
            
            TaskDuration = Double.parseDouble(hrsInStr);
            
            TaskID = TaskClass.createTaskID(TaskName, TaskNum, devDetails);
            
            TaskStatus = TaskClass.CheckingTaskStatus(tskStatus, option);
            
            JOptionPane.showMessageDialog(null, TaskClass.printTaskDetails(TaskName, TaskNum, TaskDescription, (int)TaskDuration, TaskID, TaskStatus, devDetails), "Add Task", JOptionPane.INFORMATION_MESSAGE);
            System.out.println(TaskName +"\n"+ TaskNum +"\n"+ TaskDescription +"\n"+TaskDuration+"hrs"+"\n"+ TaskID+"\n"+ TaskStatus);
            System.out.println("");
            
            store.setTaskNames(TaskName);
            store.setTaskNums(TaskNum);
            store.setTaskDescriptions(TaskDescription);
            store.setTaskDurations(TaskDuration);
            store.setTaskIDs(TaskID);
            store.setDeveloperName(devDetails);
            store.setTaskStatuses(TaskStatus);
                            
            totalHours = totalHours + (int)TaskDuration;
        }
        JOptionPane.showMessageDialog(null, "These tasks will take you " + TaskClass.returnTotalHours(totalHours) + "hrs to perform", "Add Task", JOptionPane.INFORMATION_MESSAGE);//outside the for loop
                       
    }
        
    public static boolean checkTaskDescription(String taskDescription)
    {
        int wordCount = taskDescription.length();
        if(wordCount <= 50)
        {
            System.out.println("Task successfully captured");
            return true;
        }
        else
        {
            System.out.println( "Please enter a task description of less than 50 characters");
            return false;
        }
    }
    
    public static String createTaskID(String tskName, int tskNum, String devName)
    {
        String TaskID = null;
        StringBuilder ID = new StringBuilder(tskName);//Stringbuilder is a type of object(i.e. it is not a string datatype) that edits your string characters
        ID.setLength(2); //This will set the new length of the string
        ID.append(":"); //append inserts a string character at the end of a stringbuilder
        ID.append(tskNum);
        ID.append(":");
        for(int x = 0;x < devName.length();++x)
        {
            if(devName.charAt(x) == ' ')
            {
                ID.append(devName.substring (x-3, x));
                String toUpperCase = ID.toString();
                TaskID = toUpperCase.toUpperCase();
                x = devName.length();
                
            }
        }
        return TaskID;
    }
    
    public static String printTaskDetails(String tskName, int tskNum, String taskDescription, int TaskDuration, String TaskID, String TaskStatus, String DeveloperName)
    {
        return TaskStatus +"\n"+ DeveloperName +"\n"+ tskNum +"\n"+tskName+"\n"+ taskDescription+"\n"+ TaskID + "\n" + TaskDuration + "hrs";
    }
    
    public static int returnTotalHours(int totalHours)
    {
        return totalHours;
    }
    
    public static String CheckingTaskStatus(String[] tskStatus, int option)
    {
        String TempStatus;
        option = JOptionPane.showOptionDialog(null, "Please select an option.", "Add Tasks", 0, 3, null, tskStatus , tskStatus[0]);
        switch (option){
            case 0:
                TempStatus = tskStatus[0];
                break;
            case 1:
                TempStatus  = tskStatus[1];
                break;
            case 2:
                TempStatus  = tskStatus[2];
                break;
                default:
                    TempStatus = "";
                    
        }
        return TempStatus;
        
    }
}
