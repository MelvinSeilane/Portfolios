/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package poe_exampler;

import java.util.ArrayList;
import javax.swing.JOptionPane;

/**
 *
 * @author kamogelo seilane
 */
public class StoreTasks {
    
    public void setTaskNames(String tskNames) {
        this.taskNames.add(tskNames);
    }

    public void setTaskNums(Integer tskNums) {
        this.taskNums.add(tskNums);
    }

    public void setTaskDescriptions(String tskDescriptions) {
        this.taskDescriptions.add(tskDescriptions);
    }

    public void setTaskDurations(Double TskDurations) {
        this.TaskDurations.add(TskDurations);
    }

    public void setTaskIDs(String TskIDs) {
        this.TaskIDs.add(TskIDs);
    }

    public void setTaskStatuses(String TskStatuses) {
        this.TaskStatuses.add(TskStatuses);
    }

    public void setDeveloperName(String DevNames) {
        this.DeveloperNames.add(DevNames);
    }
    private ArrayList<String> taskNames = new ArrayList<>();
    private ArrayList<Integer> taskNums = new ArrayList<>();
    private ArrayList<String> taskDescriptions = new ArrayList<>();
    private ArrayList<Double> TaskDurations = new ArrayList<>();
    private ArrayList<String> TaskIDs = new ArrayList<>();
    private ArrayList<String> TaskStatuses = new ArrayList<>();
    private ArrayList<String> DeveloperNames = new ArrayList<>();
    
    public void DisplayTskDone()
    {
        for(int count = 0; count < TaskStatuses.size(); ++count)
        {
            if(TaskStatuses.get(count).equalsIgnoreCase("done"))
            {
                JOptionPane.showMessageDialog(null, DeveloperNames.get(count) +"\n"+ taskNames.get(count) +"\n"+ TaskDurations.get(count) + "hrs", "Task's Done",JOptionPane.INFORMATION_MESSAGE); 
            }
        }
    }
    
    public void LongestTask()
    {
        double max = TaskDurations.get(0);
        int index = 0;
        for(int count = 1; count < TaskDurations.size(); ++count)
        {
            if(TaskDurations.get(count) > max)
            {
                max = TaskDurations.get(count);
                index = count;
            }
        }
        JOptionPane.showMessageDialog(null, DeveloperNames.get(index) +"\n"+ TaskDurations.get(index) + "hrs", "Longest Task", JOptionPane.INFORMATION_MESSAGE);
    }
    
    public void SearchTaskName()
    {
        String temptaskName;
        String search = JOptionPane.showInputDialog(null, "Which task name would you like to search: ", "Searching Task Name", JOptionPane.QUESTION_MESSAGE);
        for(int count = 0; count < taskNames.size(); ++count)
        {
            temptaskName = taskNames.get(count).toLowerCase();
            if(temptaskName.contains(search.toLowerCase()))
            {
                JOptionPane.showMessageDialog(null, taskNames.get(count) +"\n"+ DeveloperNames.get(count) +"\n"+ TaskStatuses.get(count), "Searching Task Name",JOptionPane.INFORMATION_MESSAGE); 
            }
            else
            {
                if(count == taskNames.size() - 1)
                {
                    JOptionPane.showMessageDialog(null, "Results where not found", "Searching Task Name", JOptionPane.ERROR_MESSAGE);
                }
            }
        }
        
        
    }
    
    public void SearchDeveloper()
    {
        String tempDeveloperDetails;
        String search = JOptionPane.showInputDialog(null, "Which develper would you like to search: ", "Searching Developer", JOptionPane.QUESTION_MESSAGE);
        for(int count = 0; count < DeveloperNames.size(); ++count)
        {
            tempDeveloperDetails = DeveloperNames.get(count).toLowerCase();
            if(tempDeveloperDetails.contains(search.toLowerCase()))
            {
                JOptionPane.showMessageDialog(null, taskNames.get(count) +"\n"+ TaskStatuses.get(count), search,JOptionPane.INFORMATION_MESSAGE); 
            }
            else
            {
                if(count == DeveloperNames.size() - 1)
                {
                    JOptionPane.showMessageDialog(null, "Results where not found", "Searching Developer", JOptionPane.ERROR_MESSAGE);
                }
            }
        }
    }
    
    public void DeleteTask()
    {
        String temptaskName;
        String search = JOptionPane.showInputDialog(null, "Which task name would you like to delete: ", "Delete Task", JOptionPane.QUESTION_MESSAGE);
        for(int count = 0; count < DeveloperNames.size(); ++count)
        {
            temptaskName = taskNames.get(count).toLowerCase();
            if(temptaskName.contains(search.toLowerCase()))
            {
                taskNames.remove(count);
                taskNums.remove(count);
                taskDescriptions.remove(count);
                TaskDurations.remove(count);
                TaskIDs.remove(count);
                TaskStatuses.remove(count);
                DeveloperNames.remove(count);
                JOptionPane.showMessageDialog(null, "Task Removed", "Delete Task", JOptionPane.INFORMATION_MESSAGE);
            }
            else
            {
                if(count == DeveloperNames.size() - 1)
                {
                    JOptionPane.showMessageDialog(null, "Results where not found", "Delete Task", JOptionPane.ERROR_MESSAGE);
                }
            }
        }
    }
    
    public void DisplayAll()
    {
        for(int count = 0; count < taskNames.size(); ++count)
        {
            JOptionPane.showMessageDialog(null, TaskStatuses.get(count) +"\n"+ DeveloperNames.get(count) +"\n"+ taskNums.get(count) +"\n"+taskNames.get(count) +"\n"+ taskDescriptions.get(count) +"\n"+ TaskIDs.get(count) + "\n" + TaskDurations.get(count) + "hrs", "Display all tasks", JOptionPane.INFORMATION_MESSAGE);
        }
    }

}
