/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package poe_exampler;

import javax.swing.JOptionPane;

/**
 *
 * @author kamogelo seilane
 */
public class Login {
     public boolean checkUserName(String userName)
    {
        boolean checkCount = false;
        boolean checkUnderScore = false;
       int wordCount = userName.length();
       if(wordCount <= 5)
       {
           checkCount = true;
           
       }
       else
       {
           //System.out.println("Your username is too long!!");
           checkCount = false;
       }
       
       if(userName.contains("_"))
           {
               checkUnderScore = true;
           }
           else
           {
               //System.out.println("You forgot to include an under score(_)!!");
               checkUnderScore = false;
           }
       
        return checkCount == true && checkUnderScore == true;
    }
    
    public boolean checkPasswordComplexity(String password)
    {
        boolean checkPassLen = false;
        boolean checkPassCap = false;
        boolean checkPassNum = false;
        boolean checkPassSpeC = false;
        int wordCount = 0;
        
        wordCount = password.length();
        
        if(wordCount >= 8)
        {
            checkPassLen = true;
        }
        else
        {
            //System.out.println("Password must be at least 8 characters long");
            checkPassLen = false;
            }
        for(int a = 0;a < wordCount;++a)
            {
                char singleC;
                for(int b = 0;b < wordCount && checkPassCap == false;++b)
                {
                    singleC = password.charAt(b);
                    if (Character.isUpperCase(singleC) == true)
                    {
                        checkPassCap = true; 
                    }
                    else
                    {
                        //System.out.println(singleC + " is not a capital letter");
                        checkPassCap = false;
                    }
                }
                
                for(int c = 0;c < wordCount && checkPassNum == false;++c)
                {
                    singleC = password.charAt(c);
                    if(Character.isDigit(singleC))
                    {
                        checkPassNum = true;
                    }
                    else
                    {
                        //System.out.println(singleC + " is not a number");
                        checkPassNum = false;
                    }
                }
                
                for(int d = 0;d < wordCount && checkPassSpeC == false;++d)
                {
                    singleC = password.charAt(d);
                    if(Character.isLetterOrDigit(singleC)== false && Character.isWhitespace(singleC) == false)
                    {
                        checkPassSpeC = true;
                    }
                    else
                    {
                        //System.out.println(singleC + " is not a special character");
                        checkPassSpeC = false;
                    }
                }
            }
            


        return checkPassLen == true && checkPassCap == true && checkPassNum == true && checkPassSpeC == true;
    }
    
    public String registerUser(boolean checkUserName,boolean checkPasswordComplexity)
    {
        String errorUserName = """
                               Username is not correctly formatted, please 
                               ensure that your username contains an 
                               underscore and is no more than 5 characters in 
                               length.""";
        String errorPassword = """
                              Password is not correctly formatted, please 
                               ensure that the password contains at least 8 
                               characters, a capital letter, a number and a 
                               special character.""";
        String confirm = "The two above conditions have been met and the user has been registered successfully.";
        if(checkUserName == true && checkPasswordComplexity == true)
            return confirm;
        else 
            //if(checkUserName == false || checkPasswordComplexity == false)
            return errorUserName + "\n or \n" + errorPassword;
    }
    
    public boolean loginUser(String userName, String password)
    {
        String logUserName;
        String logPassword;
        
        
        logUserName = JOptionPane.showInputDialog("Log in your Username");
        logPassword = JOptionPane.showInputDialog("Log in your Password");
        
        return logUserName.equals(userName) && logPassword.equals(password);
    }
    
    public String returnLoginStatus(boolean loginUser)
    {
        String success = "A successful login";
        String failure = "A failed login";
        
        if(loginUser == true)
            return success;
        else
            return failure;
    }
}
