/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package poe_exampler;

import javax.swing.JOptionPane;

/**
 *
 * @author kamogelo seilane
 */
public class POE_Exampler {
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        //Scanner userInput = new Scanner(System.in);
        Login functions = new Login();
        String userName;// = "kylry8";
        //String userName = "kyl_1";
        String password;// = "password";
        //String password = "Ch&&sec@ke99!";
        String name = "Kamogelo";
        String surname = "Seilane";
        boolean login = false;//DONT FORGET TO MAKE IT FALSE
        
        StoreTasks store = new StoreTasks();
        String[] optionsTwo = {"Task's Done", "Longest Task", "Searching Task Name", "Searching Developer", "Delete Task", "Display all tasks"};
        int optionTwo;
        int sum;
        final int EXIT = 2;
        int option = 0;
        String[] options = {"Add tasks", "Show report", "Quit"};
        
        //This is going to take user Inputs
        name = JOptionPane.showInputDialog(null, "Enter your first name :", "Registration", JOptionPane.QUESTION_MESSAGE); //"Enter your first name :", "Registration");
        surname = JOptionPane.showInputDialog(null, "Enter your last name :", "Registration", JOptionPane.QUESTION_MESSAGE);
        userName = JOptionPane.showInputDialog("Please enter a Username:");
        password = JOptionPane.showInputDialog("Please enter a Password:");
        
        //Checks if the username is valid
        System.out.println(functions.checkUserName(userName));
        if(functions.checkUserName(userName) == true)
            System.out.println("Username successfully captured");
        
        //Checks if the password is valid
        System.out.println(functions.checkPasswordComplexity(password));
        if(functions.checkPasswordComplexity(password) == true)
            System.out.println("Password successfully captured");
        
        //If username or password is invalid, the user is given 5 attempts
        for(int a = 0;a < 5 && functions.checkUserName(userName) == false || functions.checkPasswordComplexity(password) == false;++a)
        {
            JOptionPane.showMessageDialog(null, functions.registerUser(functions.checkUserName(userName),functions.checkPasswordComplexity(password)), "Registration Error",JOptionPane.ERROR_MESSAGE);
            userName = JOptionPane.showInputDialog(null, "Please enter a username:", "Registration Error",JOptionPane.ERROR_MESSAGE);
            password = JOptionPane.showInputDialog(null,"Please enter a Password:", "Registration Error",JOptionPane.ERROR_MESSAGE);
        }
        
        JOptionPane.showMessageDialog(null, functions.registerUser(functions.checkUserName(userName), functions.checkPasswordComplexity(password)), "Registration Complete", JOptionPane.INFORMATION_MESSAGE);
        login = functions.loginUser(userName, password);
        //Checks if the successfully logged in, the user is given 5 attempts to log in
        for(int b = 0;b < 5 && login == false;++b)
        {
            JOptionPane.showMessageDialog(null, "Username or password incorrect, please try again", "LOG IN ERROR",JOptionPane.ERROR_MESSAGE);
            login = functions.loginUser(userName, password);
        }
        
        
        JOptionPane.showMessageDialog(null, functions.returnLoginStatus(login), "Log In Complete", JOptionPane.INFORMATION_MESSAGE);
        
        
       //Task 2 start here
        if(login == true)
        {
            JOptionPane.showMessageDialog(null, "Welcome " + name + ", " + surname + "\n it is great to see you again");
            JOptionPane.showMessageDialog(null, "\tWelcome to EasyKanban", "Open message", JOptionPane.PLAIN_MESSAGE);//Welcome message
            option = JOptionPane.showOptionDialog(null, "Please select an option.", "Task Menu", 0, 3, null, options , options[0]);
            while(option != EXIT)//while loop for exit the program.
            {
                sum = 0;
                //switch statement to add task, Show report, Exit
                switch (option) {
                    case 0:
                        //This is the fist option
                        TaskClass.AddTask(sum, option);
                        break;
                    case 1:
                         //This is the second option
                        optionTwo = JOptionPane.showOptionDialog(null, "Please select an option.", "Altering Tasks", 0, JOptionPane.INFORMATION_MESSAGE, null, optionsTwo , optionsTwo[0]);
                        switch(optionTwo)
                        {
                            case 0: store.DisplayTskDone();
                            break;
                            
                            case 1: store.LongestTask();
                            break;
                            
                            case 2: store.SearchTaskName();
                            break;
                            
                            case 3: store.SearchDeveloper();
                            break;
                            
                            case 4: store.DeleteTask();
                            break;
                            
                            case 5: store.DisplayAll();
                            break;
                            
                            default: JOptionPane.showMessageDialog(null, "Invalid Option", "Task Menu", JOptionPane.ERROR_MESSAGE);
                        }
                    
                        break;
                    
                        
                    default:
                        JOptionPane.showMessageDialog(null, "Invalid Option", "Task Menu", JOptionPane.ERROR_MESSAGE);
                        
                }
                option = JOptionPane.showOptionDialog(null, "Please select an option.", "Task Menu", 0, 3, null, options , options[0]);
            }
            System.out.println("");
            System.out.println("You Are Out!!!");
        }
        else
            JOptionPane.showMessageDialog(null, "Failed Login", "LOG IN ERROR",JOptionPane.ERROR_MESSAGE);
    }
    //Task 2 methods found here
    
    
}
