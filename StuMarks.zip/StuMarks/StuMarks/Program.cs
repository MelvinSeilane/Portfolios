﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StuMarks
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Input marks: ");
            int marks = Convert.ToInt32(Console.ReadLine());

            if (marks == 100 || marks >= 80)
            {
                Console.WriteLine("A Grade");
            }
            else if (marks == 79 || marks >= 70)
            {
                Console.WriteLine("B Grade");
            }
            else if (marks == 69 || marks >= 60)
            {
                Console.WriteLine("C Grade");
            }
            else if (marks == 59 || marks >= 50)
            {
                Console.WriteLine("D Grade");
            }
            else if (marks == 49 || marks >= 40)
            {
                Console.WriteLine("E Grade");
            }
            else
            {
                Console.WriteLine("F Grade");
            }

            Console.ReadKey();
        }
    }
}
